// ignore_for_file: file_names

class UserModel {
  int? id;
  String? name;
  String? email;
  String? username;
  String? password;
  UserModel({this.name, this.email, this.username, this.password});
}