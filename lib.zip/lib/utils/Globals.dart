// ignore_for_file: file_names

class Globals {
  static const String urlApi = "http://perpus-api.mamorasoft.com/api/";
  static const String url = "http://perpus-api.mamorasoft.com/";
}